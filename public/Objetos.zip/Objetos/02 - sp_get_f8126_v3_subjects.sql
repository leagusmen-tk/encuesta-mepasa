SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
  Agregación cruda por CUIT (saldos / flags de período).
  Sin OperationType ARCA ni ExcludeFromReport: la exclusión/clasificación la hace la app + NuGet F8126.
*/
CREATE OR ALTER PROCEDURE dbo.sp_get_f8126_v3_subjects
    @dateFrom  DATETIME,
    @dateTo    DATETIME,
    @walletId  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @dateFrom IS NULL OR @dateTo IS NULL
    BEGIN
        RAISERROR('sp_get_f8126_v3_subjects requiere @dateFrom y @dateTo.', 16, 1);
        RETURN;
    END;

    CREATE TABLE #Accounts (
        UserId                       UNIQUEIDENTIFIER NOT NULL,
        Cuit                         NVARCHAR(50)     NOT NULL,
        PersonType                   INT              NOT NULL,
        UserType                     VARCHAR(20)      NULL,
        FullName                     NVARCHAR(200)    NULL,
        Email                        NVARCHAR(256)    NULL,
        CVU                          VARCHAR(22)      NULL,
        CreateDate                   DATETIME         NULL,
        WalletCompanyId              INT              NULL,
        WalletCompanyName            NVARCHAR(200)    NULL,
        BindAccountId                NVARCHAR(100)    NULL,
        ActivationDate               DATETIME         NULL,
        DeactivationDate             DATETIME         NULL,
        Balance                      MONEY            NOT NULL,
        HasMovementsInPeriod         BIT              NOT NULL,
        UnsubscribeDateInPeriod      DATETIME         NULL,
        SubscribeDateInPeriod        DATETIME         NULL,
        LastResultBeforePeriod       NVARCHAR(20)     NULL,
        LastResultDateBeforePeriod   DATETIME         NULL
    );

    INSERT INTO #Accounts
    EXEC dbo.sp_get_f8126_v3_accounts @dateFrom = @dateFrom, @dateTo = @dateTo, @walletId = @walletId;

    SELECT
        a.Cuit,
        MAX(a.PersonType) AS PersonType,
        MAX(a.UserType) AS UserType,
        MAX(a.FullName) AS FullName,
        MIN(a.CreateDate) AS CreateDate,
        COUNT(*) AS AccountCount,
        CAST(SUM(a.Balance) AS MONEY) AS TotalBalance,
        CAST(MAX(CAST(a.HasMovementsInPeriod AS INT)) AS BIT) AS HasMovementsInPeriod,
        MAX(a.UnsubscribeDateInPeriod) AS UnsubscribeDateInPeriod,
        MAX(a.SubscribeDateInPeriod) AS SubscribeDateInPeriod,
        MAX(a.LastResultBeforePeriod) AS LastResultBeforePeriod,
        MAX(a.LastResultDateBeforePeriod) AS LastResultDateBeforePeriod,
        (
            SELECT TOP 1 x.UserId
            FROM #Accounts x
            WHERE x.Cuit = a.Cuit
            ORDER BY x.CreateDate, x.CVU
        ) AS PrimaryUserId,
        (
            SELECT TOP 1 x.Email
            FROM #Accounts x
            WHERE x.Cuit = a.Cuit
            ORDER BY x.CreateDate, x.CVU
        ) AS PrimaryEmail,
        (
            SELECT TOP 1 x.WalletCompanyId
            FROM #Accounts x
            WHERE x.Cuit = a.Cuit
            ORDER BY x.CreateDate, x.CVU
        ) AS PrimaryWalletCompanyId
    FROM #Accounts a
    GROUP BY a.Cuit
    ORDER BY a.Cuit;

    DROP TABLE #Accounts;
END
GO
