CREATE OR ALTER VIEW dbo.vw_f8126_v3_user_base
AS
    SELECT
        u.UserId,
        u.Email,
        u.UserType,
        CASE WHEN u.UserType = 'Customer' THEN u.FullName ELSE u.CompanyName END AS FullName,
        u.CVU,
        u.CreateDate,
        i.Value AS Cuit,
        it.Code AS IdentityTypeCode,
        wc.WalletCompanyId,
        wc.Name AS WalletCompanyName,
        wc.BindAccountId,
        CASE WHEN u.UserType = 'CustomerCompany' THEN 2 ELSE 1 END AS PersonType,
        ump.ActivationDate,
        ump.DeactivationDate,
        ump.Active AS MobileActive
    FROM dbo.Users u
    INNER JOIN dbo.Identities i
        ON i.UserId = u.UserId
    INNER JOIN dbo.IdentityTypes it
        ON it.TypeId = i.TypeId
       AND it.Code = 'COMMERCIAL_IDENTITY'
    INNER JOIN dbo.WalletCompanyUsers wcu
        ON wcu.UserId = u.UserId
    INNER JOIN dbo.WalletCompanies wc
        ON wc.WalletCompanyId = wcu.WalletCompanyId
    LEFT JOIN dbo.UserMobilePhones ump
        ON ump.UserId = u.UserId
    WHERE u.UserType IN ('Customer', 'CustomerCompany')
      AND u.CVU IS NOT NULL
      AND LEN(LTRIM(RTRIM(u.CVU))) > 0
      AND i.Value IS NOT NULL
      AND LEN(LTRIM(RTRIM(i.Value))) > 0;
GO
