SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
  Datos crudos de cuentas/CVU para F8126 V3.
  Sin clasificación ARCA (códigos 01/02/03, exclude, etc.): eso lo hace Hasar.Inlet.ReportsAfip.F8126.
*/
CREATE OR ALTER PROCEDURE dbo.sp_get_f8126_v3_accounts
    @dateFrom  DATETIME,
    @dateTo    DATETIME,
    @walletId  INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @dateFrom IS NULL OR @dateTo IS NULL
    BEGIN
        RAISERROR('sp_get_f8126_v3_accounts requiere @dateFrom y @dateTo.', 16, 1);
        RETURN;
    END;

    DECLARE @dateToInclusive DATETIME = DATEADD(ms, -3, CAST(DATEADD(day, 1, CAST(@dateTo AS DATE)) AS DATETIME));

    ;WITH CashIn AS (
        SELECT
            o.ReceiverUserId AS UserId,
            CASE WHEN o.OrderFlag = 5 THEN od.NetAmountIn ELSE 0 END AS Amount,
            o.CompanyReference,
            COALESCE(o.OrderAccreditationDate, o.OrderConfirmationDate, o.OrderDate) AS MoveDate,
            o.OrderFlag
        FROM dbo.Orders o
        INNER JOIN dbo.OrderDetails od ON od.OrderId = o.OrderId
        INNER JOIN dbo.PaymentMethods pm ON pm.PaymentMethodId = o.PayOutMethodId
        WHERE pm.Name = 'Cta. Virtual'
    ),
    CashOut AS (
        SELECT
            o.SenderUserId AS UserId,
            CASE WHEN o.OrderFlag NOT IN (0, 1) THEN -od.NetAmountOut ELSE 0 END AS Amount,
            o.CompanyReference,
            COALESCE(o.OrderAccreditationDate, o.OrderConfirmationDate, o.OrderDate) AS MoveDate,
            o.OrderFlag
        FROM dbo.Orders o
        INNER JOIN dbo.OrderDetails od ON od.OrderId = o.OrderId
        INNER JOIN dbo.PaymentMethods pm ON pm.PaymentMethodId = o.SendOutMethodId
        WHERE pm.Name = 'Cta. Virtual' OR o.OperationType = 18 /* PAYMENT_DEBIN */
    ),
    AllMoves AS (
        SELECT * FROM CashIn
        UNION ALL
        SELECT * FROM CashOut
    ),
    MovesUntilPeriod AS (
        SELECT *
        FROM AllMoves
        WHERE MoveDate <= @dateToInclusive
    ),
    RunningBalance AS (
        SELECT
            UserId,
            CompanyReference,
            Amount,
            SUM(Amount) OVER (PARTITION BY UserId ORDER BY CompanyReference) AS Balance
        FROM MovesUntilPeriod
    ),
    LastBalance AS (
        SELECT
            UserId,
            Balance,
            ROW_NUMBER() OVER (PARTITION BY UserId ORDER BY CompanyReference DESC) AS Rn
        FROM RunningBalance
    ),
    PeriodMoves AS (
        SELECT DISTINCT UserId
        FROM AllMoves
        WHERE MoveDate >= @dateFrom
          AND MoveDate <= @dateToInclusive
          AND OrderFlag = 5
    ),
    BcraInPeriod AS (
        SELECT
            b.IdentityValue,
            MAX(CASE WHEN r.Code = 'BAJA' THEN b.Date END) AS UnsubscribeDateInPeriod,
            MAX(CASE WHEN r.Code = 'ALTA' THEN b.Date END) AS SubscribeDateInPeriod
        FROM dbo.BcraCensusRegisters b
        INNER JOIN dbo.BcraCensusResults r ON r.BcraCensusResultId = b.ResultId
        WHERE b.Date >= @dateFrom
          AND b.Date <= @dateToInclusive
        GROUP BY b.IdentityValue
    ),
    BcraBeforePeriod AS (
        SELECT
            x.IdentityValue,
            x.Code AS LastResultBeforePeriod,
            x.Date AS LastResultDateBeforePeriod
        FROM (
            SELECT
                b.IdentityValue,
                r.Code,
                b.Date,
                ROW_NUMBER() OVER (PARTITION BY b.IdentityValue ORDER BY b.Date DESC) AS Rn
            FROM dbo.BcraCensusRegisters b
            INNER JOIN dbo.BcraCensusResults r ON r.BcraCensusResultId = b.ResultId
            WHERE b.Date < @dateFrom
        ) x
        WHERE x.Rn = 1
    )
    SELECT
        ub.UserId,
        ub.Cuit,
        ub.PersonType,
        ub.UserType,
        ub.FullName,
        ub.Email,
        ub.CVU,
        ub.CreateDate,
        ub.WalletCompanyId,
        ub.WalletCompanyName,
        ub.BindAccountId,
        ub.ActivationDate,
        ub.DeactivationDate,
        CAST(ISNULL(lb.Balance, 0) AS MONEY) AS Balance,
        CAST(CASE WHEN pm.UserId IS NOT NULL THEN 1 ELSE 0 END AS BIT) AS HasMovementsInPeriod,
        bip.UnsubscribeDateInPeriod,
        bip.SubscribeDateInPeriod,
        bbp.LastResultBeforePeriod,
        bbp.LastResultDateBeforePeriod
    FROM dbo.vw_f8126_v3_user_base ub
    LEFT JOIN LastBalance lb
        ON lb.UserId = ub.UserId AND lb.Rn = 1
    LEFT JOIN PeriodMoves pm
        ON pm.UserId = ub.UserId
    LEFT JOIN BcraInPeriod bip
        ON bip.IdentityValue = ub.Cuit
    LEFT JOIN BcraBeforePeriod bbp
        ON bbp.IdentityValue = ub.Cuit
    WHERE ub.CreateDate <= @dateToInclusive
      AND (@walletId IS NULL OR ub.WalletCompanyId = @walletId)
    ORDER BY ub.Cuit, ub.CVU;
END
GO
