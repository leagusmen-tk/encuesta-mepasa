SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
  Movimientos del período para F8126 V3 (datos crudos).
  Sin códigos ARCA (SuggestedDetailCode / AfipOperationType): los mapea el consumidor + Hasar.Inlet.ReportsAfip.F8126.
*/
CREATE OR ALTER PROCEDURE dbo.sp_get_f8126_v3_movements
    @dateFrom  DATETIME,
    @dateTo    DATETIME,
    @walletId  INT = NULL,
    @cuit      NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @dateFrom IS NULL OR @dateTo IS NULL
    BEGIN
        RAISERROR('sp_get_f8126_v3_movements requiere @dateFrom y @dateTo.', 16, 1);
        RETURN;
    END;

    DECLARE @dateToInclusive DATETIME = DATEADD(ms, -3, CAST(DATEADD(day, 1, CAST(@dateTo AS DATE)) AS DATETIME));

    ;WITH BaseUsers AS (
        SELECT ub.*
        FROM dbo.vw_f8126_v3_user_base ub
        WHERE (@walletId IS NULL OR ub.WalletCompanyId = @walletId)
          AND (@cuit IS NULL OR ub.Cuit = @cuit)
    ),
    CashIn AS (
        SELECT
            ub.UserId AS PartitionUserId,
            ub.Cuit,
            ub.PersonType,
            ub.UserType,
            ub.CVU AS PartitionCVU,
            ub.Email AS PartitionUserName,
            ub.FullName AS PartitionFullName,
            ub.WalletCompanyId,
            ub.BindAccountId,
            o.CompanyReference,
            o.OrderFlag,
            o.OperationType,
            o.Concept,
            o.SubConcept,
            od.NetAmountIn AS Amount,
            od.TotalAmountIn AS TotalAmount,
            od.TotalCustomerCommission AS Commission,
            od.LegalTax AS Tax,
            COALESCE(o.OrderAccreditationDate, o.OrderConfirmationDate, o.OrderDate) AS MoveDate,
            o.OrderAccreditationDate,
            o.SenderUserId,
            o.SenderCBU,
            o.SenderCVU,
            o.ReceiverUserId,
            o.ReceiverCBU,
            o.ReceiverCVU,
            CAST(1 AS BIT) AS IsIngreso,
            et.ExternalTransactionId,
            et.Code AS ExternalTransactionCode,
            et.Name AS ExternalTransactionName,
            wt.Code AS ExternalAfipCode
        FROM dbo.Orders o
        INNER JOIN dbo.OrderDetails od ON od.OrderId = o.OrderId
        INNER JOIN dbo.PaymentMethods pm ON pm.PaymentMethodId = o.PayOutMethodId
        INNER JOIN BaseUsers ub ON ub.UserId = o.ReceiverUserId
        LEFT JOIN dbo.ExternalTransactions et ON et.ExternalTransactionId = o.SubConcept
        LEFT JOIN dbo.WalletTags wt ON wt.WalletTagId = et.AfipCodeV3Id
        WHERE pm.Name = 'Cta. Virtual'
          AND o.OrderFlag = 5
    ),
    CashOut AS (
        SELECT
            ub.UserId AS PartitionUserId,
            ub.Cuit,
            ub.PersonType,
            ub.UserType,
            ub.CVU AS PartitionCVU,
            ub.Email AS PartitionUserName,
            ub.FullName AS PartitionFullName,
            ub.WalletCompanyId,
            ub.BindAccountId,
            o.CompanyReference,
            o.OrderFlag,
            o.OperationType,
            o.Concept,
            o.SubConcept,
            -od.NetAmountOut AS Amount,
            od.TotalAmountIn AS TotalAmount,
            od.TotalCustomerCommission AS Commission,
            od.LegalTax AS Tax,
            COALESCE(o.OrderAccreditationDate, o.OrderConfirmationDate, o.OrderDate) AS MoveDate,
            o.OrderAccreditationDate,
            o.SenderUserId,
            o.SenderCBU,
            o.SenderCVU,
            o.ReceiverUserId,
            o.ReceiverCBU,
            o.ReceiverCVU,
            CAST(0 AS BIT) AS IsIngreso,
            et.ExternalTransactionId,
            et.Code AS ExternalTransactionCode,
            et.Name AS ExternalTransactionName,
            wt.Code AS ExternalAfipCode
        FROM dbo.Orders o
        INNER JOIN dbo.OrderDetails od ON od.OrderId = o.OrderId
        INNER JOIN dbo.PaymentMethods pm ON pm.PaymentMethodId = o.SendOutMethodId
        INNER JOIN BaseUsers ub ON ub.UserId = o.SenderUserId
        LEFT JOIN dbo.ExternalTransactions et ON et.ExternalTransactionId = o.SubConcept
        LEFT JOIN dbo.WalletTags wt ON wt.WalletTagId = et.AfipCodeV3Id
        WHERE (pm.Name = 'Cta. Virtual' OR o.OperationType = 18)
          AND o.OrderFlag = 5
    ),
    UnionMoves AS (
        SELECT * FROM CashIn
        UNION ALL
        SELECT * FROM CashOut
    )
    SELECT
        m.PartitionUserId,
        m.Cuit,
        m.PersonType,
        m.UserType,
        m.PartitionCVU,
        m.PartitionUserName,
        m.PartitionFullName,
        m.WalletCompanyId,
        m.BindAccountId,
        m.CompanyReference,
        m.OrderFlag,
        m.OperationType,
        m.Concept,
        m.SubConcept,
        CAST(m.Amount AS MONEY) AS SignedAmount,
        CAST(ABS(m.Amount) AS MONEY) AS Amount,
        CAST(m.TotalAmount AS MONEY) AS TotalAmount,
        CAST(m.Commission AS MONEY) AS Commission,
        CAST(m.Tax AS MONEY) AS Tax,
        m.MoveDate,
        m.OrderAccreditationDate,
        m.IsIngreso,
        m.SenderUserId,
        m.SenderCBU,
        m.SenderCVU,
        m.ReceiverUserId,
        m.ReceiverCBU,
        m.ReceiverCVU,
        CASE
            WHEN m.IsIngreso = 1 THEN COALESCE(NULLIF(m.SenderCBU, ''), NULLIF(m.SenderCVU, ''))
            ELSE COALESCE(NULLIF(m.ReceiverCBU, ''), NULLIF(m.ReceiverCVU, ''))
        END AS CounterpartyCbuCvu,
        m.ExternalTransactionId,
        m.ExternalTransactionCode,
        m.ExternalTransactionName,
        m.ExternalAfipCode
    FROM UnionMoves m
    WHERE m.MoveDate >= @dateFrom
      AND m.MoveDate <= @dateToInclusive
    ORDER BY m.Cuit, m.PartitionUserId, m.CompanyReference;
END
GO
