USE [bv-core];

BEGIN TRANSACTION;

IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ExternalTransactions_AfipCode')
BEGIN
    ALTER TABLE dbo.ExternalTransactions DROP CONSTRAINT FK_ExternalTransactions_AfipCode;
END;

IF COL_LENGTH(N'dbo.ExternalTransactions', N'AfipCodeV2Id') IS NULL
   AND COL_LENGTH(N'dbo.ExternalTransactions', N'AfipCodeId') IS NOT NULL
BEGIN
    EXEC sp_rename N'dbo.ExternalTransactions.AfipCodeId', N'AfipCodeV2Id', N'COLUMN';
END;

IF COL_LENGTH(N'dbo.ExternalTransactions', N'AppliesAfipV2') IS NULL
   AND COL_LENGTH(N'dbo.ExternalTransactions', N'AppliesAfip') IS NOT NULL
BEGIN
    EXEC sp_rename N'dbo.ExternalTransactions.AppliesAfip', N'AppliesAfipV2', N'COLUMN';
END;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ExternalTransactions_AfipCodeV2')
BEGIN
    ALTER TABLE dbo.ExternalTransactions
        ADD CONSTRAINT FK_ExternalTransactions_AfipCodeV2
        FOREIGN KEY (AfipCodeV2Id) REFERENCES dbo.WalletTags(WalletTagId);
END;

IF COL_LENGTH(N'dbo.ExternalTransactions', N'AfipCodeV3Id') IS NULL
BEGIN
    ALTER TABLE dbo.ExternalTransactions ADD AfipCodeV3Id INT NULL;
END;

IF COL_LENGTH(N'dbo.ExternalTransactions', N'AppliesAfipV3') IS NULL
BEGIN
    ALTER TABLE dbo.ExternalTransactions
        ADD AppliesAfipV3 BIT NOT NULL
            CONSTRAINT DF_ET_AppliesAfipV3 DEFAULT (0);
END;

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_ExternalTransactions_AfipCodeV3')
BEGIN
    ALTER TABLE dbo.ExternalTransactions
        ADD CONSTRAINT FK_ExternalTransactions_AfipCodeV3
        FOREIGN KEY (AfipCodeV3Id) REFERENCES dbo.WalletTags(WalletTagId);
END;

INSERT INTO dbo.WalletTags (Code, Name, CategoryCode)
SELECT source.Code, source.Name, N'AFIP_CODE_V3'
FROM (VALUES
    (N'AFIP_CODE_V3_01', N'01 - Efectivo'),
    (N'AFIP_CODE_V3_02', N'02 - Transferencia a/de terceros'),
    (N'AFIP_CODE_V3_03', N'03 - Transferencia propia'),
    (N'AFIP_CODE_V3_04', N'04 - Prestamos'),
    (N'AFIP_CODE_V3_05', N'05 - Rendimientos inversiones'),
    (N'AFIP_CODE_V3_06', N'06 - Devoluciones'),
    (N'AFIP_CODE_V3_07', N'07 - Compra/venta ME'),
    (N'AFIP_CODE_V3_08', N'08 - Pagos con transferencia (QR/POS)'),
    (N'AFIP_CODE_V3_09', N'09 - Otros')
) AS source (Code, Name)
WHERE NOT EXISTS (SELECT 1 FROM dbo.WalletTags wt WHERE wt.Code = source.Code);

IF NOT EXISTS (
    SELECT 1
    FROM dbo._MigrationHistory
    WHERE MigrationId = N'288 - ExternalTransactions AFIP 8126 V2 y V3'
)
BEGIN
    INSERT INTO dbo._MigrationHistory (MigrationId, [Date], Author)
    VALUES (N'288 - ExternalTransactions AFIP 8126 V2 y V3', GETDATE(), N'Javier Acosta');
END;

COMMIT TRANSACTION;
