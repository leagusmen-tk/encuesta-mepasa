USE [bv-core]
GO

/*
  Datos de configuración F8126 V3 (límites default).
  Definiciones versionadas de objetos:
    - Database/Views/vw_f8126_v3_user_base.sql
    - Database/StoreProcedures/sp_get_f8126_v3_accounts.sql
    - Database/StoreProcedures/sp_get_f8126_v3_subjects.sql
    - Database/StoreProcedures/sp_get_f8126_v3_movements.sql
*/

IF NOT EXISTS (SELECT 1 FROM dbo.Parameters WHERE Name = 'AFIP_8126_V3_BALANCE_LIMIT_PF')
BEGIN
    INSERT INTO dbo.Parameters (ParameterId, Name, Value, Type)
    VALUES (NEWID(), 'AFIP_8126_V3_BALANCE_LIMIT_PF', '50000000', 'Decimal');
END

IF NOT EXISTS (SELECT 1 FROM dbo.Parameters WHERE Name = 'AFIP_8126_V3_TRX_LIMIT_PF')
BEGIN
    INSERT INTO dbo.Parameters (ParameterId, Name, Value, Type)
    VALUES (NEWID(), 'AFIP_8126_V3_TRX_LIMIT_PF', '2500000', 'Decimal');
END

IF NOT EXISTS (SELECT 1 FROM dbo.Parameters WHERE Name = 'AFIP_8126_V3_BALANCE_LIMIT_PJ')
BEGIN
    INSERT INTO dbo.Parameters (ParameterId, Name, Value, Type)
    VALUES (NEWID(), 'AFIP_8126_V3_BALANCE_LIMIT_PJ', '30000000', 'Decimal');
END

IF NOT EXISTS (SELECT 1 FROM dbo.Parameters WHERE Name = 'AFIP_8126_V3_TRX_LIMIT_PJ')
BEGIN
    INSERT INTO dbo.Parameters (ParameterId, Name, Value, Type)
    VALUES (NEWID(), 'AFIP_8126_V3_TRX_LIMIT_PJ', '1500000', 'Decimal');
END
GO

INSERT INTO dbo.[_MigrationHistory] ([MigrationId], [Date], [Author])
VALUES (N'279 - Formulario AFIP 8126 V3 - parametros limites', GETDATE(), N'Cursor Agent');
GO
